package com.capgemini.Personal;


import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	WebDriver driver;

	@Given("^I have a Personal detail form$")
	public void i_have_a_Personal_detail_form() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Saurabh Mishra\\Jar Files\\Selenium Jar file\\ChromeDriver\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.get(
				"C:\\sts-bundle\\BDD\\EmployeeProjectwithHtmlCSSAndJavascript_BDD2\\src\\main\\webapp\\Personal.html");
		Thread.sleep(1000);

	}

	@When("^Employee Id is \"([^\"]*)\", name \"([^\"]*)\", city \"([^\"]*)\" and State \"([^\"]*)\"$")
	public void employee_Id_is_name_city_and_State(String arg1, String arg2, String arg3, String arg4)
			throws InterruptedException {

		WebElement id = driver.findElement(By.name("empno"));
		id.click();
		id.sendKeys(arg1);
		Thread.sleep(1000);

		WebElement name = driver.findElement(By.name("name"));
		name.click();
		name.sendKeys(arg2);
		Thread.sleep(1000);

		Select city = new Select(driver.findElement(By.name("city")));
		city.selectByVisibleText(arg3);

		WebElement state = driver.findElement(By.name("state"));
		state.click();
		state.sendKeys(arg4);
		Thread.sleep(1000);

	}

	
	
	
	@Then("^Proceed to Next Page having the title as \"([^\"]*)\"$")
	public void proceed_to_Next_Page_having_the_title_as(String arg1) {
		driver.findElement(By.name("Submit Button")).click();
		String title=driver.getTitle();
		assertEquals(arg1,title);
	}

	@Then("^Show a popup Alert Message as \"([^\"]*)\"$")
	public void show_a_popup_Alert_Message_as(String arg1){
		driver.findElement(By.name("Submit Button")).click();
		if (this.isAlertPresent()) {
			String alertMessage=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
			assertEquals(alertMessage, arg1);
		}
		
	}
	

	
	
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
