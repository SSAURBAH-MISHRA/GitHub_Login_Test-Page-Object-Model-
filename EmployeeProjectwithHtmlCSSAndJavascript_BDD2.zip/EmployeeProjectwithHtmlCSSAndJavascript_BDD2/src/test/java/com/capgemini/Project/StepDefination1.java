package com.capgemini.Project;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination1 {
	WebDriver driver;
	
	

@Given("^I have a Project Detail form$")
public void i_have_a_Project_Detail_form() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver",
			"C:\\Saurabh Mishra\\Jar Files\\Selenium Jar file\\ChromeDriver\\chromedriver.exe");

	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	driver.get("C:\\sts-bundle\\BDD\\EmployeeProjectwithHtmlCSSAndJavascript_BDD2\\src\\main\\webapp\\Project.html");
	Thread.sleep(1000);
}

@When("^Project name is \"([^\"]*)\" and Project Platform is \"([^\"]*)\"$")
public void project_name_is_and_Project_Platform_is(String arg1, String arg2) throws InterruptedException {
	
	
	WebElement name=driver.findElement(By.name("name"));
	name.click();
	name.sendKeys(arg1);
	Thread.sleep(1000);

	driver.findElement(By.cssSelector("input[value='"+arg2+"']")).click();
	
//	Select platform = new Select(driver.findElement(By.name("platform")));
//	platform.selectByVisibleText(arg2);
}
	
	
	@Then("^Proceed to Next Page having the title as \"([^\"]*)\"$")
	public void proceed_to_Next_Page_having_the_title_as(String arg1){

		driver.findElement(By.name("Submit Button")).click();
		String title=driver.getTitle();
		assertEquals(arg1,title);
	}

	
	@Then("^Show a popup Alert Message as \"([^\"]*)\"$")
	public void show_a_popup_Alert_Message_as(String arg1){
		driver.findElement(By.name("Submit Button")).click();
		if (this.isAlertPresent()) {
			String alertMessage=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
			assertEquals(alertMessage, arg1);
		}
	}
		
		public boolean isAlertPresent() {
			try {
				driver.switchTo().alert();
				return true;
			} catch (Exception e) {
				return false;
			}
		}
}
