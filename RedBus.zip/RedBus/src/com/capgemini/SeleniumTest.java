package com.capgemini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Saurabh Mishra\\Jar Files\\Selenium Jar file\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.redbus.in/");
		driver.manage().window().maximize();
		
		// to include text using id
		WebElement src = driver.findElement(By.id("src"));
		src.click();
		src.sendKeys("Pune");
		src.click();
		Thread.sleep(1000);

		WebElement dest = driver.findElement(By.id("dest"));
		dest.click();
		dest.sendKeys("Chennai");
		dest.click();
		Thread.sleep(1000);
		
		
//to pick Onward date
		driver.findElement(By.xpath("//*[@class='fl search-box date-box gtm-onwardCalendar']")).click();
		System.out.println("onward date box got clicked");
		String month = "Apr 2019";
		String date = "28";
		String getMonth = driver.findElement(By.xpath("//div[@class='rb-calendar']//td[@class='monthTitle']"))
				.getText();
		System.out.println(getMonth);
		while (true) {
			if ((getMonth.equalsIgnoreCase(month))) {
				break;
			}
			driver.findElement(By.xpath("//div[@class='rb-calendar']/*//td[@class='next']")).click();
			getMonth = driver.findElement(By.xpath("//div[@class='rb-calendar']//td[@class='monthTitle']")).getText();
		}
		driver.findElement(By.xpath("//div[@id='rb-calendar_onward_cal']/table/tbody//td[text()='" + month
				+ "']/../..//td[text()='" + date + "']")).click();
		System.out.println("onward date got picked");
		
		
		
//to pick Return date
		driver.findElement(By.xpath("//*[@class='fl search-box date-box gtm-returnCalendar']")).click();
		System.out.println("return date box got clicked");
		String rmonth = "Apr 2019";
		String rdate = "29";
		String rgetMonth = driver.findElement(By.xpath("//div[@class='rb-calendar']//td[@class='monthTitle']"))
				.getText();
		System.out.println(rgetMonth);

		while (true) {
			if ((rgetMonth.equalsIgnoreCase(rmonth))) {
				break;
			}
			driver.findElement(By.xpath("//div[@class='rb-calendar']/*//td[@class='next']")).click();
			rgetMonth = driver.findElement(By.xpath("//div[@class='rb-calendar']//td[@class='monthTitle']")).getText();

		}
		driver.findElement(By.xpath("//div[@id='rb-calendar_return_cal']/table/tbody//td[text()='" + rmonth
				+ "']/../..//td[text()='" + rdate + "']")).click();
		System.out.println("return date got picked");
		Thread.sleep(1000);
		
//to click on search button
		driver.findElement(By.id("search_btn")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id=\"8368723\"]/div/div[2]/div[1]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"rt_8368723\"]/div/div/div/div[2]/div[2]/div[2]")).click();
	}
}
