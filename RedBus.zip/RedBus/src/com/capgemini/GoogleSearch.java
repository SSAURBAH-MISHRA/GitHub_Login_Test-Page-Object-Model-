package com.capgemini;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class GoogleSearch {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Saurabh Mishra\\Jar Files\\Selenium Jar file\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		
		WebElement search = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input"));
		search.click();
		search.sendKeys("Pune");
		driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"hdtb-msb-vis\"]/div[4]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"ZbqAgecIPWE-UM:\"]")).click();
		Thread.sleep(1000);
		
		Actions action = new Actions(driver);
		WebElement link = driver.findElement(By.xpath("//*[@class=\"irc_mil i3597\"]"));
		action.contextClick(link).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
		WebElement elementq =driver.findElement(By.xpath("//*[@id=\"irc_cc\"]/div[2]/div[1]/div[2]/div[1]/a/img")); 
		Actions builderq = new Actions(driver); 
		builderq.contextClick(elementq);
		builderq.build().perform();
}
}