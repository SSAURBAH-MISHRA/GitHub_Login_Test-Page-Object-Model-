package com.capgemini.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.capgemini.Base.TestBase;
import com.capgemini.pages.AboutPage;
import com.capgemini.pages.HomePage;
import com.capgemini.pages.LoginPage;

public class PageTest extends TestBase {
	static LoginPage loginPage;
	static HomePage homePage;
	static AboutPage aboutPage;
	
	public PageTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@Test(priority=1)
	public void loginPageTitleTest() throws InterruptedException{
		String title = loginPage.validateLoginPageTitle();
		assertEquals(title, "Sign in to GitHub · GitHub");
		Thread.sleep(5000);
	}
	
//	@Test
//	public void loginTest() throws InterruptedException{
//		aboutPage = loginPage.login("smishr25", "Brahmtist@1234");
//		Thread.sleep(3000);
//		assertTrue(aboutPage.checkLinkIsPresentOrNot());
//	}
	
	
	@Test(priority=2)
	public void loginTest() throws InterruptedException{
		aboutPage=loginPage.login("smishr25", "MyGithubPassword");
		Thread.sleep(10000);
	}
	
	@Test(priority=3)
	public void checkLinkInAboutPage() throws InterruptedException
	{
		assertTrue(aboutPage.checkLinkIsPresentOrNot());
	}
	
	
	@AfterClass
	public static  void tearDown(){
		driver.quit();
	}
	
	
	
	

}
