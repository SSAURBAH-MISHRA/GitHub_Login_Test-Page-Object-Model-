package com.capgemini.pages;

import org.openqa.selenium.support.PageFactory;

import com.capgemini.Base.TestBase;

public class HomePage extends TestBase{

	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	


}
