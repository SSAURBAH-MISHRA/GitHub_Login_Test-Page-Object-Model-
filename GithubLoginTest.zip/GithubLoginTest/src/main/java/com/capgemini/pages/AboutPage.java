package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.Base.TestBase;

public class AboutPage extends TestBase {
	
	public AboutPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="/html/body/div[4]/div/div/div/div/div[2]/ul[1]/li[2]/a")
	WebElement aboutGithub;
	@FindBy(xpath="/html/body/div[4]/main/div/div/div[3]/div[1]/a/h3")
	WebElement careersInGithub;
	

	public boolean checkLinkIsPresentOrNot() throws InterruptedException
	{
		aboutGithub.click();
		Thread.sleep(5000);
		careersInGithub.click();
		Thread.sleep(10000);
		return true;
	}
}
