package com.capgemini.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.Base.TestBase;


public class LoginPage extends TestBase{
	
	//Page Factory - OR:
	@FindBy(name="login")
	WebElement username;
	
	@FindBy(name="password")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"login\"]/form/div[3]/input[4]")
	WebElement signInButton;
	
	@FindBy(xpath="//*[@id=\"login\"]/p/a")
	WebElement signUpButton;
	
	
	//Initializing the Page Objects:
	public LoginPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	public String validateLoginPageTitle(){
		return driver.getTitle();
	}
	
	public AboutPage login(String usern, String passwrd){
		username.sendKeys(usern);
		password.sendKeys(passwrd);
		signInButton.click();
		    	/*JavascriptExecutor js = (JavascriptExecutor)driver;
		    	js.executeScript("arguments[0].click();", loginBtn);*/
		    	
		return new AboutPage();
	}
}
	
